library(ggplot2)
plt_simu_pois = function(n,lambda){
  set.seed(2)
  u = simu_pois(n = 100, lambda)
  ggplot() + geom_histogram(aes(u), binwidth = 1, fill = "white", color = "black")
}