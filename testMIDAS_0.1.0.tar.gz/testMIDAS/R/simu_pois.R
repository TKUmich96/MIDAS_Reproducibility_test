simu_pois = function(n=100,lambda){
  set.seed(2)
  return(rpois(n, lambda))
}